﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTestLinkedListHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestLinkedListHelpersTests
{
    [TestClass()]
    public class LinkedListTests
    {
        [TestMethod()]
        public void LinkedListTest()
        {
            LinkedList<Char> letter_stream = new LinkedList<char>(),                            
                             expected_stream = new LinkedList<char>();

            letter_stream.AddLast('E');
            letter_stream.AddLast('B');
            letter_stream.AddLast('E');
            letter_stream.AddLast('E');
            letter_stream.AddLast('B');
            letter_stream.AddLast('A');
            letter_stream.AddLast('B');

            expected_stream.AddLast('E');
            expected_stream.AddLast('B');
            expected_stream.AddLast('E');
            expected_stream.AddLast('B');
            expected_stream.AddLast('A');

            LinkedList list = new LinkedList(letter_stream);
            Assert.AreEqual(list.new_stream, expected_stream);
            
        }
    }
}