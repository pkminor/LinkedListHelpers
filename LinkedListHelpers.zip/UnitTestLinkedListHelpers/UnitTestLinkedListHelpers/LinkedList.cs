﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestLinkedListHelpers
{
    public class LinkedList
    {
        public LinkedList<char> new_stream;
        public LinkedList(LinkedList<char> letters_stream)
        {
            new_stream = LinkedListHelpers.LinkedListHelpers.pairTrim(letters_stream, 2);
        }
    }
}
