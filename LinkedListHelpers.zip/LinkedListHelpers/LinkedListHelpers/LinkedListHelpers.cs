﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkedListHelpers
{
    public static class LinkedListHelpers
    {
        static public LinkedList<char> pairTrim(LinkedList<char> letter_stream, int max_count = 2)
        {
            LinkedList<char> temp_stream = new LinkedList<char>();

            Dictionary<char, Int32> letter_count = new Dictionary<char, int>();

            foreach (char l in letter_stream)
            {

                if (letter_count.ContainsKey(l)) { letter_count[l] += 1; }
                else { letter_count[l] = 1; }

                if (letter_count[l] <= max_count)
                {
                    temp_stream.AddLast(l);
                }

            }

            letter_stream = temp_stream;
            temp_stream = null;

            return letter_stream;
        }
    }
}
